package dev.debaleen.foodrunner.model

data class FAQModel(
    val question: String,
    val answer: String
)